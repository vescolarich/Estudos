
// Dados sobre a bola
let xB = 300
let yB = 200
let dB = 24
let raio = 12
let velocidadeB = 4
let velocidadeB2 = 8

// Dados sobre Raquete
let xR = 15
let yR = 150
let lR = 12
let aR = 80


// Dados sobre Raquete Adversario
let xRad = 560
let yRad = 150 
let lRad = 12
let aRad = 80 

// Placar
let pJ = 0
let pO = 0

//Som
let raquetada
let trilha
let ponto


function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(20);
  xBola();
  Raquete()
  RaqueteAdversario()
  Pontuacao()
  colisao()
  
}

function xBola() {
  circle (xB,yB,dB)
  xB += velocidadeB
  yB += velocidadeB2
 
  if (xB > width || xB < 0){
    velocidadeB *= -1
 }
 if (yB > height || yB < 0){
   velocidadeB2 *= -1
 }
}

 function Raquete(){
   rect(xR,yR,lR,aR)
   
   if(keyIsDown(UP_ARROW)){
     yR -= 10
   }
   if(keyIsDown(DOWN_ARROW)){
     yR += 10
   }
 }

 
 
function RaqueteAdversario (){
   rect(xRad,yRad,lRad,aRad)
  if(keyIsDown(87)){
    yRad -= 10
  } 
  if(keyIsDown(83))
    yRad += 10

if(xB > xRad && yB < yRad + aR && yB > yRad){
       velocidadeB *= -1 
}
}
function Pontuacao(){
  fill(255)
  text(pJ,250,26)
  text(pO,320,26)
  
  if (xB + raio > 613) {
    pJ += 1;
  }
  
  if (xB < 0){
    pO += 1
  }
}
  function colisao(){
   if(xB - raio < xR && yB < yR + aR && yB > yR){
      
     velocidadeB *= -1
   }   
}
