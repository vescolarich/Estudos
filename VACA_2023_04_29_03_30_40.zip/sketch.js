
function setup() {
  createCanvas(500, 400);
  
}

function draw() {
  background(estrada);
  mostraImagens()
  movimentacao()
  loopCarros()
  pontuacao()
  Contagem()
  Colisao()
  plmds()
  
  
}
