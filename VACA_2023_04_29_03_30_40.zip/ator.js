//Ator
let yA1 = 368
let xA1 = 20
let colisao1 = false
let colisao2 = false
let colisao3 = false
let colisao4 = false
let colisao5 = false 
let colisao6 = false

function movimentacao(){
  if(keyIsDown(UP_ARROW)){
    yA1 -= 3
  }  
  if (keyIsDown(DOWN_ARROW))
    if (yA1 < 368)
    yA1 += 3
  if(keyIsDown(RIGHT_ARROW)){
    xA1 += 3
  }
  if (keyIsDown(LEFT_ARROW)){
    xA1 -= 3
  }
}

function Colisao(){
 for (let i = 0; i < imagemCarro.length; i = i + 1){
    colisao1 = collideRectCircle(xCarros[0],yCarros[0],50,40,xA1,yA1,15)
    colisao2 = collideRectCircle(xCarros[1],yCarros[1],50,40,xA1,yA1,15)
    colisao3 = collideRectCircle(xCarros[2],yCarros[2],50,40,xA1,yA1,15)
    colisao4 = collideRectCircle(xCarros[3],yCarros[3],50,40,xA1,yA1,15)
    colisao5 = collideRectCircle(xCarros[4],yCarros[4],50,40,xA1,yA1,15)
    colisao6 = collideRectCircle(xCarros[5],yCarros[5],50,40,xA1,yA1,15)
    
  if(colisao1){
    yA1 = 368
    pontos -= 1
    colidiu.play()
  }
   if(colisao2){
    yA1 = 368
    pontos -= 1
    colidiu.play()
}
   if(colisao3){
    yA1 = 368
    pontos -= 1
    colidiu.play()
   }
   if(colisao4){
    yA1 = 368
    pontos -= 1
    colidiu.play()
   }
   if(colisao5){
    yA1 = 368
    pontos -= 1
    colidiu.play()
   }
   if(colisao6){
    yA1 = 368
    pontos -= 1
    colidiu.play()
   }
}
}