let pontos = 0
let reseto = false

function pontuacao(){
  fill ('purple')
  rect(220, 8, 50, 20)
  textAlign(CENTER)
}

function Contagem(){
  fill('black')
  textSize(18)
  text(pontos,245,25)
  
  if(yA1 < 10){
   pontos += 1
  pontosS.play()
  }
}
function plmds (){
  reseto = yA1 < 10
 if (reseto){
  yA1 = 368 
}
  if(pontos < 0)
    pontos *= 0
}