// Carros
let velocidadeCarros = [7,5,4,3.5,6,4]
let xCarros = [600,400,210,500,100,200]
let yCarros = [40,95,150,210,262,314]
let lCarros = [50]
let aCarros = [40]


function preload(){
  estrada = loadImage("img/estrada.png")
  ator = loadImage ("img/ator-1.png")
  carro = loadImage("img/carro.png")
  carro2 = loadImage("img/carro-2.png")
  carro3 = loadImage ("img/carro-3.png")
  imagemCarro = [carro,carro2,carro3]
  trilha = loadSound("Sons/trilha-1.mp3")
  colidiu = loadSound("Sons/colidiu.mp3")
  pontosS = loadSound("Sons/pontosS.wav")
}
  function mostraImagens(){
  image(imagemCarro[0],xCarros[0],yCarros[0],lCarros[0],aCarros[0])
  image(imagemCarro[1],xCarros[1],yCarros[1],lCarros[0],aCarros[0])
  image(imagemCarro[2],xCarros[2],yCarros[2],lCarros[0],aCarros[0])
  image(ator,xA1,yA1,30,30)
  image(imagemCarro[1],xCarros[3],yCarros[3],lCarros[0],aCarros[0])
  image(imagemCarro[2],xCarros[4],yCarros[4],lCarros[0],aCarros[0])
  image(imagemCarro[0],xCarros[5],yCarros[5],lCarros[0],aCarros[0])
  
    //velocidade dos carros
  xCarros [0] -=  velocidadeCarros[0]
  xCarros [1] -=  velocidadeCarros[1]
  xCarros [2] -=  velocidadeCarros[2]
  xCarros [3] -=  velocidadeCarros[3]
  xCarros [4] -=  velocidadeCarros[4]
  xCarros [5] -=  velocidadeCarros[5]
}
function loopCarros(){
  if(xCarros[0] < -40){
    xCarros[0] = 600
  }
if(xCarros[1] < -40){
    xCarros[1] = 500
}
  if(xCarros[2] < -40){
    xCarros[2] = 520 }

  if(xCarros [3] < -40){
    xCarros[3] = 500
  }
  if(xCarros[4] < -40){
    xCarros[4] = 600
  }
  if(xCarros[5] < -40){
    xCarros[5] = 600
  }
}

